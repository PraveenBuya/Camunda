package com.example.demo.jobworker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;

@Component
public class CheckBalanceListener {
	
	private final static Logger LOG = LoggerFactory.getLogger(CheckBalanceListener.class);

	@JobWorker(type = "checkBalance")
	public void jobWorkerTesting(final JobClient client, final ActivatedJob job) {
		final String balance = (String) job.getVariablesAsMap().get("balanceAmount");
		if (balance == null || balance.isEmpty()) {
			// check if the balance is empty
			throw new RuntimeException("Balance is empty");
		}
		
		job.getVariablesAsMap().put("jobworkerlistener", "true");
		LOG.info("Sending email with balance content: {} and Jobworker {}", balance, job.getVariablesAsMap().get("jobworkerlistener"));
	}
	
	
	@JobWorker(type = "startOfCheckBalance")
	public void startOfServiceTaskListener(final JobClient client, final ActivatedJob job) {
		final String balance = (String) job.getVariablesAsMap().get("balanceAmount");
		job.getVariablesAsMap().put("startOfListener", "true");
		LOG.info("Sending email with balance content: {} and startOfListener {}", balance, job.getVariablesAsMap().get("startOfListener"));
	}
	
	
	@JobWorker(type = "endOfCheckBalance")
	public void endOfServiceTaskListener(final JobClient client, final ActivatedJob job) {
		final String balance = (String) job.getVariablesAsMap().get("balanceAmount");
		job.getVariablesAsMap().put("endOfCheckBalance", "true");
		LOG.info("Sending email with balance content: {} and endOfCheckBalance {}", balance, job.getVariablesAsMap().get("endOfCheckBalance"));
	}
	
	@JobWorker(type = "finalValidationCompletingEvent")
	public void finalValidationCompletingEventTaskListener(final JobClient client, final ActivatedJob job) {
		final String balance = (String) job.getVariablesAsMap().get("balanceAmount");
		job.getVariablesAsMap().put("finalValidationCompletingEvent", "true");
		LOG.info("Sending email with balance content: {} and finalValidationCompletingEvent {}", balance, job.getVariablesAsMap().get("finalValidationCompletingEvent"));
	}
	
	@JobWorker(type = "assigningEventTaskListener")
	public void assigningEventTaskListener(final JobClient client, final ActivatedJob job) {
		final String balance = (String) job.getVariablesAsMap().get("balanceAmount");
		job.getVariablesAsMap().put("assigningEventTaskListener", "true");
		LOG.info("Sending email with balance content: {} and assigningEventTaskListener {}", balance, job.getVariablesAsMap().get("assigningEventTaskListener"));
	}
	
	

}
