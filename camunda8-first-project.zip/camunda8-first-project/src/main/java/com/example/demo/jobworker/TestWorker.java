package com.example.demo.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import org.springframework.stereotype.Component;

@Component
public class TestWorker {

  @JobWorker(type = "testJobWorker")
  public void testMethod(final JobClient client, final ActivatedJob job) throws Exception {
    String variable1 = (String) job.getVariablesAsMap().get("variable1");
    System.out.println(variable1);
    System.out.println("TestWorker is working on job " + job.getKey());
    // client.newCompleteCommand(job.getKey()).send().
  }
}
