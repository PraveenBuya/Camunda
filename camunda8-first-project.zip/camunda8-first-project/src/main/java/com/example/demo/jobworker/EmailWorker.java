package com.example.demo.jobworker;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.Variable;
import io.camunda.zeebe.spring.common.exception.ZeebeBpmnError;

@Component
public class EmailWorker {

	private final static Logger LOG = LoggerFactory.getLogger(EmailWorker.class);

	/*
	 * The @JobWorker annotation marks the method to be automatically subscribed to
	 * jobs of type trackOrderStatus when the application starts. This is part of
	 * the Camunda Zeebe Spring client integration.
	 * 
	 * JobClient: the client to interact with the job
	 * 
	 * ActivatedJob: the job instance containing details such as variables
	 * 
	 * In a Spring Boot application that uses the Zeebe Spring client, the lifecycle
	 * of job workers is managed by the Spring application context. When the Spring
	 * application context is closed or the application is shut down, it should
	 * automatically close any resources that are tied to the application lifecycle,
	 * including Zeebe job workers.
	 * 
	 * By default, the autoComplete attribute is set to true for any job worker. You
	 * don't need to call client.newCompleteCommand(). In this case, the Spring
	 * integration will handle job completion for you.
	 * 
	 */
	@JobWorker(type = "email")
	public void sendEmail(final JobClient client, final ActivatedJob job) {
		final String message_content = (String) job.getVariablesAsMap().get("message_content");
		LOG.info("Sending email with message content: {}", message_content);
	}
	
	
	
	@JobWorker(type = "foo", name = "job",enabled = false,autoComplete = false)
	public void handleJobFoo(final JobClient client, final ActivatedJob job, @Variable(name = "variable1") String variable1) {
		LOG.info("Handling job foo with variable1: {}", variable1);
		client.newCompleteCommand(job.getKey()).send().join();
	}
	
	
	@JobWorker(type = "foo", fetchVariables={"variable1", "variable2"},enabled = false)
	public void handleJobFoo(final JobClient client, final ActivatedJob job) {
	  String variable1 = (String)job.getVariablesAsMap().get("variable1");
	  System.out.println(variable1);
	  // ...
	}
	
	
	@JobWorker(type = "foo",enabled = false)
	public Map<String, Object> handleJobFoo(final ActivatedJob job) {
		final String message_content = (String) job.getVariablesAsMap().get("message_content");
	  // some work
	  if (true) {
	    // some data is returned to be stored as process variable
	    return job.getVariablesAsMap();
	  } else {
	   // problem shall be indicated to the process:
	   throw new ZeebeBpmnError("DOESNT_WORK", "This does not work because...", null);
	  }
	}


}