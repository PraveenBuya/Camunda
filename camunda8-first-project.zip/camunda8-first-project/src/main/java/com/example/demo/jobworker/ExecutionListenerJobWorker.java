package com.example.demo.jobworker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.common.exception.ZeebeBpmnError;

@Component
public class ExecutionListenerJobWorker {

	private final static Logger LOG = LoggerFactory.getLogger(ExecutionListenerJobWorker.class);

	@JobWorker(type = "startExecutionListener")
	public void startExecutionListenerTest(final JobClient client, final ActivatedJob job) {
		final String message_content = (String) job.getVariablesAsMap().get("message_content");
		job.getVariablesAsMap().put("startExecutionListener", "true");
		LOG.info("Sending email with message content: {} and startExecutionListener {}", message_content, job.getVariablesAsMap().get("startExecutionListener"));
	}
	
	
	@JobWorker(type = "endExecutionListener")
	public void endExecutionListenerTest(final JobClient client, final ActivatedJob job) {
		final String message_content = (String) job.getVariablesAsMap().get("message_content");
		job.getVariablesAsMap().put("endExecutionListener", "true");
		LOG.info("Sending email with message content: {} and endExecutionListener {}", message_content, job.getVariablesAsMap().get("endExecutionListener"));
	}
	
	
	@JobWorker(type = "mainJobWorker")
	public void mainJobWorkerTest(final JobClient client, final ActivatedJob job) {
		final String message_content = (String) job.getVariablesAsMap().get("message_content");
		if(message_content == null || message_content.isEmpty()) {
             //check if the message content is empty
             throw new ZeebeBpmnError("NO_MESSAGE_CONTENT", "Message content is empty", null);
        }
		job.getVariablesAsMap().put("mainJobWorker", "true");
		LOG.info("Sending email with message content: {} and mainJobWorker {}", message_content, job.getVariablesAsMap().get("mainJobWorker"));
	}

}
