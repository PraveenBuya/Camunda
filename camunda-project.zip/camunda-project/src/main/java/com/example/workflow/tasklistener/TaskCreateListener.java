package com.example.workflow.tasklistener;

import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class TaskCreateListener implements TaskListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskCreateListener.class);

    @Override
    public void notify(DelegateTask delegateTask) {
        // Log task creation
        LOGGER.info("Task Created: ID={}, Name={}", delegateTask.getId(), delegateTask.getName());

        // Set a variable for tracking
        delegateTask.setVariable("creationTimestamp", System.currentTimeMillis());

        // Optionally assign the task to a default user
        delegateTask.setAssignee("defaultUser");

        // Additional logic can be added here
        LOGGER.info("Assigned default user to Task ID={}", delegateTask.getId());
    }
}
