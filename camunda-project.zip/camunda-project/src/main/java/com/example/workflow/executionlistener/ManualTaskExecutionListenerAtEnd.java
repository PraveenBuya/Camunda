package com.example.workflow.executionlistener;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class ManualTaskExecutionListenerAtEnd implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) throws Exception {
        // Use the injected fields
      
        String message = "Execution listener at End of Manual Task";
        System.out.println("Execution listener at End of Manual Task");
        // Set the message as a process variable
        execution.setVariable("EndlistenerMessage", message);
    }
}
