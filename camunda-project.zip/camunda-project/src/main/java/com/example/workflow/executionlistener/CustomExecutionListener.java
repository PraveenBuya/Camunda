package com.example.workflow.executionlistener;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class CustomExecutionListener implements ExecutionListener {

    private String message; // Field to be injected
    private String priority; // Another field to demonstrate multiple injections

    // Setter methods for field injection
    public void setMessage(String message) {
        this.message = message;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    @Override
    public void notify(DelegateExecution execution) throws Exception {
        // Use the injected fields
        System.out.println("Injected Message: " + message);
        System.out.println("Injected Priority: " + priority);

        // Set the message as a process variable
        execution.setVariable("listenerMessage", message);
    }
}
