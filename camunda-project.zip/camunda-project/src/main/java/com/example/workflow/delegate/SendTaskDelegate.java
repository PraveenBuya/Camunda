package com.example.workflow.delegate;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class SendTaskDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        // Get the business key
        String businessKey = execution.getProcessBusinessKey();

        // Simulate sending a message
        System.out.println("Order request sent for business key: " + businessKey);

        // Add custom logic to send a message (e.g., HTTP request to another system)
    }
}
