package com.example.workflow.service;

import org.springframework.stereotype.Service;

@Service
public class SimpleService {
	
	public String generateMessage() {
		System.out.println("SimpleService executed");
		return "Hello World";
	}

}
