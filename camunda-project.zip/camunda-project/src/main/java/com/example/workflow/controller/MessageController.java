package com.example.workflow.controller;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private RuntimeService runtimeService;

    /**
     * Correlates a message to a process instance using a business key.
     *
     * @param messageName The name of the message (defined in BPMN as messageRef)
     * @param businessKey The unique business key for the process instance
     * @return ResponseEntity indicating success or failure
     */
    @PostMapping("/correlate")
    public ResponseEntity<String> correlateMessage(
            @RequestParam(name = "messageName") String messageName,
            @RequestParam(name = "businessKey") String businessKey) {
        try {
            // Correlate the message to the process instance with the specified business key
            runtimeService.createMessageCorrelation(messageName)
                    .processInstanceBusinessKey(businessKey)
                    .correlate();

            return ResponseEntity.ok("Message '" + messageName + "' correlated successfully for business key: " + businessKey);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to correlate message: " + e.getMessage());
        }
    }
}
