package com.example.workflow.delegate;

import org.camunda.bpm.engine.delegate.JavaDelegate;

public class TestDelegateWithJava implements JavaDelegate{
	
	@Override
	public void execute(org.camunda.bpm.engine.delegate.DelegateExecution execution) throws Exception {
		System.out.println("TestDelegateWithJava executed");
		
	}

}
