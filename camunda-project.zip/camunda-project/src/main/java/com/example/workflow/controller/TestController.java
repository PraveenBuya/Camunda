package com.example.workflow.controller;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.runtime.ProcessInstantiationBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@GetMapping("/getTest")
	public String test() {
		return "Hello World!";
	}
	
	@GetMapping("/getTest2")
	public String test2() {
//		ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
//		ProcessInstantiationBuilder instantiationBuilder =  processEngine.getRuntimeService().createProcessInstanceByKey("FirstProcess");
//		
//		instantiationBuilder.setVariable("name", "ALEX");
//		instantiationBuilder.executeWithVariablesInReturn();
		
		
		ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
		ProcessInstantiationBuilder instantiationBuilder =  processEngine.getRuntimeService().createProcessInstanceByKey("DeploymentThroughSpringBootProcess");
		
		instantiationBuilder.setVariable("name", "ALEX");
		instantiationBuilder.setVariable("email", "testemail.com");
		instantiationBuilder.executeWithVariablesInReturn();
		
		return "Started Process Instance!!";
	}
	
}
