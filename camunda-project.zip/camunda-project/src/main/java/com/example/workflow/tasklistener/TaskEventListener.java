package com.example.workflow.tasklistener;
import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.springframework.stereotype.Component;

@Component
public class TaskEventListener implements TaskListener {

    @Override
    public void notify(DelegateTask delegateTask) {
        String eventName = delegateTask.getEventName();

        switch (eventName) {
            case TaskListener.EVENTNAME_CREATE:
                handleTaskCreate(delegateTask);
                break;
            case TaskListener.EVENTNAME_ASSIGNMENT:
                handleTaskAssignment(delegateTask);
                break;
            case TaskListener.EVENTNAME_COMPLETE:
                handleTaskComplete(delegateTask);
                break;
            case TaskListener.EVENTNAME_DELETE:
                handleTaskDelete(delegateTask);
                break;
            default:
                System.out.println("Unknown event: " + eventName);
        }
    }

    private void handleTaskCreate(DelegateTask delegateTask) {
        System.out.println("Task Created: " + delegateTask.getName());
        delegateTask.setVariable("creationTime", System.currentTimeMillis());
    }

    private void handleTaskAssignment(DelegateTask delegateTask) {
        System.out.println("Task Assigned to: " + delegateTask.getAssignee());
    }

    private void handleTaskComplete(DelegateTask delegateTask) {
        System.out.println("Task Completed: " + delegateTask.getId());
    }

    private void handleTaskDelete(DelegateTask delegateTask) {
        System.out.println("Task Deleted: " + delegateTask.getId());
    }
}
