package com.example.workflow.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class AgeValidatorDelegator  implements JavaDelegate{
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		int age = (int) execution.getVariable("age");
		
		if(age < 18) {
            execution.setVariable("validAge", false);
            } else {
            	execution.setVariable("validAge", true);
            }
		
		System.out.println("AgeValidatorDelegator executed");
	}

}
