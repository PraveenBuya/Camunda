var studentObj = {
	    name: 'John',
	    age: 25,
	    subject: 'English'
	    };
	    
	    var studentJson = JSON.stringify(studentObj);
	    
	    print(studentJson);
	    print("Printing User Object from previous script task:::"+JSON.stringify(UserObject));
	    print("Printing Global User Object from previous script task:::"+JSON.stringify(globalUserObj1));