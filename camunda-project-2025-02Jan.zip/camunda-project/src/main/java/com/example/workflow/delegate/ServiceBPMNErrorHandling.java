package com.example.workflow.delegate;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class ServiceBPMNErrorHandling implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		try {
			String inventoryAvaiable = (String) execution.getVariable("inventoryAvailable");
			int quantity = (int) execution.getVariable("quantity");
			int amount = (int) execution.getVariable("amount");

			if (inventoryAvaiable.equals("no")) {
//			System.out.println("Inventory is not available for the product");
//			execution.setVariable("status", "failed");
				throw new BpmnError("specificerror", "Inventory is not available for the product");

			}
			if (amount < 100) {
				throw new BpmnError("testError","Amount is less than 100");
			}

		} catch (BpmnError e) {
			System.out.println("Error: " + e.getMessage());
			throw e;

		} catch (Exception e) {
			throw e;
		}
	}
}
