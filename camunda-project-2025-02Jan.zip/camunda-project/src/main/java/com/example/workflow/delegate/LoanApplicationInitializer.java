package com.example.workflow.delegate;

import java.util.ArrayList;
import java.util.List;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class LoanApplicationInitializer implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        List<String> ordersList = new ArrayList<>();
        ordersList.add("Television");
        ordersList.add("Airconditioner");
        ordersList.add("Pizza");
        execution.setVariable("ordersList", ordersList);
        execution.setVariable("ordersSize", ordersList.size());
        

    }
}