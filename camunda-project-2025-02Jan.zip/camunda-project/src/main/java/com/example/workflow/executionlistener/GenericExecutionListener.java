package com.example.workflow.executionlistener;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.engine.impl.el.FixedValue;
import org.springframework.stereotype.Component;

@Component
public class GenericExecutionListener implements ExecutionListener {

    private FixedValue listenerType; // Field to be injected

//    // Setter methods for field injection
//    public void setListenerType(FixedValue listenerType) {
//        this.listenerType = listenerType;
//    }


    @Override
    public void notify(DelegateExecution execution) throws Exception {
    	 // Unwrap the FixedValue to get the actual value
        String fieldValue = (listenerType != null) ? (String) listenerType.getValue(execution) : null;
    	
    	System.out.println("INjected value is " + fieldValue);
		if (fieldValue.equals("startListener")) {
			String message = "Execution listener at start of " + execution.getCurrentActivityName();
			System.out.println(message);
			// Set the message as a process variable
			execution.setVariable("GenericStartlistenerMessage", message);
		} else if (fieldValue.equals("endListener")) {
			String message = "Execution listener at end of " + execution.getCurrentActivityName();
			System.out.println(message);
			// Set the message as a process variable
			execution.setVariable("GenericEndlistenerMessage", message);
		} else {
			System.out.println("Did not set field value correctly");
		}
		
    }
}
