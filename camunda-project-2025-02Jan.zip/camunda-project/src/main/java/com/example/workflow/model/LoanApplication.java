package com.example.workflow.model;

public class LoanApplication implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String email;
	private String phone;
	private String loanType;
	private double amount;

	// Constructor
	public LoanApplication(String name, String email, String phone, String loanType, double amount) {
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.loanType = loanType;
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "LoanApplication{" + "name='" + name + '\'' + ", email='" + email + '\'' + ", phone='" + phone + '\''
				+ ", loanType='" + loanType + '\'' + ", amount=" + amount + '}';
	}

}
