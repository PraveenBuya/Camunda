package com.example.workflow.executionlistener;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class UserTaskExecutionListenerAtStart implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) throws Exception {
        // Use the injected fields
      
        String message = "UserTask Execution Listener at start";
        System.out.println(message);
        // Set the message as a process variable
        execution.setVariable("UserTaskStartlistenerMessage", message);
    }
}
